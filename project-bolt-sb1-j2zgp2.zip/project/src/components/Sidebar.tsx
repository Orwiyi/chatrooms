import React from 'react';
import { MessageSquare, Users, Settings, Search, Menu, Gamepad2, Tv, Book, Palette } from 'lucide-react';

interface SidebarProps {
  isCollapsed: boolean;
  onToggle: () => void;
}

const categories = [
  { id: 'anime', name: 'Anime', icon: Tv, rooms: ['General', 'Seasonal', 'Movies'] },
  { id: 'manga', name: 'Manga', icon: Book, rooms: ['Discussion', 'Releases', 'Scanlation'] },
  { id: 'games', name: 'Games', icon: Gamepad2, rooms: ['JRPG', 'Visual Novels', 'Mobile'] },
  { id: 'art', name: 'Art & Cosplay', icon: Palette, rooms: ['Fan Art', 'Cosplay', 'Photography'] },
];

export default function Sidebar({ isCollapsed, onToggle }: SidebarProps) {
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 flex items-center justify-between border-b border-gray-700">
        {!isCollapsed && <h1 className="text-xl font-bold">ImprovedConcept</h1>}
        <button onClick={onToggle} className="p-2 hover:bg-gray-700 rounded-lg">
          <Menu size={20} />
        </button>
      </div>

      {/* Search */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
          <input
            type="text"
            placeholder={isCollapsed ? '' : 'Search...'}
            className="w-full bg-gray-700 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Categories */}
      <div className="flex-1 overflow-y-auto">
        {categories.map((category) => (
          <div key={category.id} className="mb-4">
            <div className={`px-4 py-2 flex items-center ${!isCollapsed ? 'justify-between' : 'justify-center'}`}>
              <div className="flex items-center space-x-2">
                <category.icon size={20} className="text-gray-400" />
                {!isCollapsed && <span className="font-medium">{category.name}</span>}
              </div>
            </div>
            {!isCollapsed && (
              <div className="mt-1">
                {category.rooms.map((room) => (
                  <button
                    key={room}
                    className="w-full px-6 py-1.5 text-left text-gray-300 hover:bg-gray-700 text-sm"
                  >
                    # {room}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* User Controls */}
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-4">
          <img
            src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop"
            alt="Profile"
            className="w-8 h-8 rounded-full"
          />
          {!isCollapsed && (
            <div className="flex-1">
              <h3 className="text-sm font-medium">Sarah Chen</h3>
              <p className="text-xs text-gray-400">Online</p>
            </div>
          )}
          <Settings size={20} className="text-gray-400 cursor-pointer hover:text-white" />
        </div>
      </div>
    </div>
  );
}