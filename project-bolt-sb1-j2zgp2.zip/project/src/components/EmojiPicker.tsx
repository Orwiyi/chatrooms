import React from 'react';
import data from '@emoji-mart/data';
import Picker from '@emoji-mart/react';

interface EmojiPickerProps {
  onEmojiSelect: (emoji: any) => void;
  onClose: () => void;
}

export default function EmojiPicker({ onEmojiSelect, onClose }: EmojiPickerProps) {
  return (
    <div className="absolute bottom-16 right-0 z-50">
      <div className="fixed inset-0" onClick={onClose} />
      <Picker 
        data={data} 
        onEmojiSelect={onEmojiSelect}
        theme="dark"
        previewPosition="none"
        skinTonePosition="none"
      />
    </div>
  );
}