import React, { useState } from 'react';
import { Search, X } from 'lucide-react';
import { useSearch } from '../lib/hooks/useSearch';
import type { Message } from '../lib/types';

interface SearchMessagesProps {
  roomId: string;
  onMessageSelect: (messageId: string) => void;
}

export default function SearchMessages({ roomId, onMessageSelect }: SearchMessagesProps) {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const { results, isSearching } = useSearch(roomId, query);

  const handleSelect = (messageId: string) => {
    onMessageSelect(messageId);
    setIsOpen(false);
    setQuery('');
  };

  return (
    <div className="relative">
      <div className="flex items-center space-x-2">
        <div className="relative flex-1">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsOpen(true)}
            placeholder="Search messages..."
            className="w-full bg-gray-700 rounded-lg pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="absolute right-3 top-2.5 text-gray-400 hover:text-white"
            >
              <X size={16} />
            </button>
          )}
        </div>
      </div>

      {isOpen && query && (
        <div className="absolute top-12 left-0 right-0 bg-gray-800 rounded-lg shadow-lg max-h-96 overflow-y-auto">
          {isSearching ? (
            <div className="p-4 text-center text-gray-400">Searching...</div>
          ) : results.length > 0 ? (
            <div className="divide-y divide-gray-700">
              {results.map((message) => (
                <button
                  key={message.id}
                  onClick={() => handleSelect(message.id)}
                  className="w-full p-4 text-left hover:bg-gray-700 flex items-start space-x-3"
                >
                  <img
                    src={`https://api.dicebear.com/7.x/avatars/svg?seed=${message.userId}`}
                    alt="avatar"
                    className="w-8 h-8 rounded-full bg-gray-700"
                  />
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-sm">{message.userId}</span>
                      <span className="text-xs text-gray-400">
                        {format(new Date(message.timestamp), 'MMM d, p')}
                      </span>
                    </div>
                    <p className="text-sm text-gray-300">{message.content}</p>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-gray-400">No messages found</div>
          )}
        </div>
      )}
    </div>
  );
}