import React, { useRef } from 'react';
import { Paperclip, X } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (files: File[]) => void;
  selectedFiles: File[];
  onRemoveFile: (index: number) => void;
}

export default function FileUpload({ onFileSelect, selectedFiles, onRemoveFile }: FileUploadProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    onFileSelect(files);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="relative">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={handleFileSelect}
        accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
      />
      <button
        type="button"
        onClick={() => fileInputRef.current?.click()}
        className="text-gray-400 hover:text-white"
      >
        <Paperclip size={20} />
      </button>
      
      {selectedFiles.length > 0 && (
        <div className="absolute bottom-16 left-0 bg-gray-800 rounded-lg p-2 shadow-lg w-72">
          <div className="text-sm font-medium mb-2">Selected Files:</div>
          <div className="space-y-2">
            {selectedFiles.map((file, index) => (
              <div key={index} className="flex items-center justify-between bg-gray-700 rounded p-2">
                <div className="truncate flex-1 text-sm">{file.name}</div>
                <button
                  type="button"
                  onClick={() => onRemoveFile(index)}
                  className="ml-2 text-gray-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}