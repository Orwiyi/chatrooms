import React, { useEffect, useRef, useState } from 'react';
import { Send, Smile } from 'lucide-react';
import { useChat } from '../lib/hooks/useChat';
import { format } from 'date-fns';
import EmojiPicker from './EmojiPicker';
import FileUpload from './FileUpload';
import VoiceRecorder from './VoiceRecorder';
import MessageReactions from './MessageReactions';
import MessageThread from './MessageThread';
import SearchMessages from './SearchMessages';
import type { Message } from '../lib/types';

interface ChatRoomProps {
  roomId: string;
}

export default function ChatRoom({ roomId }: ChatRoomProps) {
  const [message, setMessage] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const { messages, isTyping, sendMessage, startTyping, stopTyping, addReaction } = useChat(roomId);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout>();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() && selectedFiles.length === 0) return;

    sendMessage(message, selectedFiles, replyingTo?.id);
    setMessage('');
    setSelectedFiles([]);
    setReplyingTo(null);
    stopTyping();
  };

  const handleTyping = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessage(e.target.value);

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    startTyping();
    typingTimeoutRef.current = setTimeout(stopTyping, 1000);
  };

  const handleVoiceRecording = async (blob: Blob) => {
    const file = new File([blob], 'voice-message.webm', { type: 'audio/webm' });
    setSelectedFiles(prev => [...prev, file]);
  };

  const handleMessageSelect = (messageId: string) => {
    const message = messages.find(m => m.id === messageId);
    if (message) {
      const element = document.getElementById(`message-${messageId}`);
      element?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      element?.classList.add('bg-purple-500/10');
      setTimeout(() => element?.classList.remove('bg-purple-500/10'), 2000);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="px-6 py-4 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">#{roomId}</h2>
            <p className="text-sm text-gray-400">3,241 members</p>
          </div>
          <SearchMessages roomId={roomId} onMessageSelect={handleMessageSelect} />
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6 space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} id={`message-${msg.id}`} className="group">
            <div className="flex items-start space-x-4">
              <img 
                src={`https://api.dicebear.com/7.x/avatars/svg?seed=${msg.userId}`} 
                alt="avatar" 
                className="w-10 h-10 rounded-full bg-gray-700"
              />
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <span className="font-medium">{msg.userId}</span>
                  <span className="text-xs text-gray-400">
                    {format(new Date(msg.timestamp), 'p')}
                  </span>
                </div>
                {msg.replyTo && (
                  <div className="mt-1 ml-4 pl-4 border-l-2 border-gray-700">
                    <div className="text-sm text-gray-400">
                      Replying to {msg.replyTo.userId}
                    </div>
                    <div className="text-sm text-gray-300">{msg.replyTo.content}</div>
                  </div>
                )}
                <p className="mt-1 text-gray-300">{msg.content}</p>
                {msg.attachments?.map((attachment, index) => (
                  <div key={index} className="mt-2">
                    {attachment.type === 'image' ? (
                      <img 
                        src={attachment.url} 
                        alt={attachment.name}
                        className="max-w-md rounded-lg"
                      />
                    ) : attachment.type === 'audio' ? (
                      <audio controls className="mt-2">
                        <source src={attachment.url} type="audio/webm" />
                      </audio>
                    ) : (
                      <a 
                        href={attachment.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-blue-400 hover:underline text-sm"
                      >
                        {attachment.name}
                      </a>
                    )}
                  </div>
                ))}
                <MessageReactions 
                  reactions={msg.reactions || {}}
                  onReact={(emoji) => addReaction(msg.id, emoji)}
                />
                <MessageThread
                  message={msg}
                  replies={messages.filter(m => m.replyTo?.id === msg.id)}
                  onReply={() => setReplyingTo(msg)}
                />
              </div>
            </div>
          </div>
        ))}
        {isTyping.length > 0 && (
          <div className="text-sm text-gray-400 italic">
            {isTyping.join(', ')} {isTyping.length === 1 ? 'is' : 'are'} typing...
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Reply Preview */}
      {replyingTo && (
        <div className="px-4 py-2 bg-gray-800 border-t border-gray-700 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-sm text-gray-400">
            <span>Replying to {replyingTo.userId}</span>
            <span className="truncate">{replyingTo.content}</span>
          </div>
          <button
            onClick={() => setReplyingTo(null)}
            className="text-gray-400 hover:text-white"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-gray-700">
        <div className="flex items-center space-x-4">
          <FileUpload
            onFileSelect={handleFileSelect}
            selectedFiles={selectedFiles}
            onRemoveFile={(index) => {
              setSelectedFiles(prev => prev.filter((_, i) => i !== index));
            }}
          />
          <VoiceRecorder onRecordingComplete={handleVoiceRecording} />
          <div className="flex-1 bg-gray-700 rounded-lg flex items-center">
            <input
              type="text"
              value={message}
              onChange={handleTyping}
              placeholder="Type a message..."
              className="flex-1 bg-transparent px-4 py-2 focus:outline-none"
            />
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                className="p-2 text-gray-400 hover:text-white"
              >
                <Smile size={20} />
              </button>
              {showEmojiPicker && (
                <EmojiPicker
                  onEmojiSelect={(emoji) => {
                    setMessage(prev => prev + emoji.native);
                    setShowEmojiPicker(false);
                  }}
                  onClose={() => setShowEmojiPicker(false)}
                />
              )}
            </div>
          </div>
          <button 
            type="submit" 
            className="bg-purple-600 p-2 rounded-lg hover:bg-purple-700 disabled:opacity-50"
            disabled={!message.trim() && selectedFiles.length === 0}
          >
            <Send size={20} />
          </button>
        </div>
      </form>
    </div>
  );
}