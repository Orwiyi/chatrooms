import React, { useState } from 'react';
import { SmilePlus } from 'lucide-react';
import EmojiPicker from './EmojiPicker';

interface MessageReactionsProps {
  reactions: Record<string, string[]>;
  onReact: (emoji: string) => void;
}

export default function MessageReactions({ reactions, onReact }: MessageReactionsProps) {
  const [showPicker, setShowPicker] = useState(false);

  return (
    <div className="mt-2 flex items-center space-x-2">
      {Object.entries(reactions).map(([emoji, users]) => (
        <button
          key={emoji}
          onClick={() => onReact(emoji)}
          className="inline-flex items-center space-x-1 bg-gray-700 hover:bg-gray-600 rounded-full px-2 py-0.5 text-sm"
        >
          <span>{emoji}</span>
          <span className="text-gray-400">{users.length}</span>
        </button>
      ))}
      <div className="relative">
        <button
          type="button"
          onClick={() => setShowPicker(!showPicker)}
          className="text-gray-400 hover:text-white p-1 rounded-full hover:bg-gray-700"
        >
          <SmilePlus size={16} />
        </button>
        {showPicker && (
          <EmojiPicker
            onEmojiSelect={(emoji) => {
              onReact(emoji.native);
              setShowPicker(false);
            }}
            onClose={() => setShowPicker(false)}
          />
        )}
      </div>
    </div>
  );
}