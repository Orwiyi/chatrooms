import React from 'react';
import { Users } from 'lucide-react';

const onlineUsers = [
  { id: '1', name: 'Yuki', avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=50&h=50&fit=crop', status: 'online' },
  { id: '2', name: 'Alex', avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=50&h=50&fit=crop', status: 'online' },
  { id: '3', name: 'Mei', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50&h=50&fit=crop', status: 'idle' },
  { id: '4', name: 'Kai', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=50&h=50&fit=crop', status: 'dnd' }
];

export default function UserProfile() {
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <Users size={20} />
          <h2 className="text-lg font-semibold">Online Members</h2>
        </div>
      </div>

      {/* Online Users List */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="space-y-4">
          {onlineUsers.map((user) => (
            <div key={user.id} className="flex items-center space-x-3">
              <div className="relative">
                <img src={user.avatar} alt={user.name} className="w-10 h-10 rounded-full" />
                <span className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-gray-800 
                  ${user.status === 'online' ? 'bg-green-500' : 
                    user.status === 'idle' ? 'bg-yellow-500' : 'bg-red-500'}`} />
              </div>
              <div>
                <h3 className="font-medium">{user.name}</h3>
                <p className="text-sm text-gray-400 capitalize">{user.status}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Room Info */}
      <div className="p-4 border-t border-gray-700">
        <h3 className="font-semibold mb-2">Room Details</h3>
        <div className="space-y-2 text-sm text-gray-400">
          <p>Created: March 15, 2024</p>
          <p>Category: Anime Discussion</p>
          <p>Language: English</p>
        </div>
      </div>
    </div>
  );
}