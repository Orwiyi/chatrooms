import React, { useState, useRef } from 'react';
import { Mic, Square, Loader2 } from 'lucide-react';
import useSound from 'use-sound';

interface VoiceRecorderProps {
  onRecordingComplete: (blob: Blob) => void;
}

export default function VoiceRecorder({ onRecordingComplete }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const timerRef = useRef<NodeJS.Timeout>();
  const chunksRef = useRef<Blob[]>([]);
  
  const [playBeep] = useSound('/sounds/beep.mp3');

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorderRef.current = new MediaRecorder(stream);
      
      mediaRecorderRef.current.ondataavailable = (e) => {
        chunksRef.current.push(e.data);
      };

      mediaRecorderRef.current.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        onRecordingComplete(blob);
        chunksRef.current = [];
        setRecordingTime(0);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
      playBeep();

      timerRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Error accessing microphone:', err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      clearInterval(timerRef.current);
      setIsRecording(false);
      playBeep();
      
      const tracks = mediaRecorderRef.current.stream.getTracks();
      tracks.forEach(track => track.stop());
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="relative">
      {isRecording ? (
        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={stopRecording}
            className="text-red-500 hover:text-red-400 animate-pulse"
          >
            <Square size={20} />
          </button>
          <span className="text-sm text-gray-400">{formatTime(recordingTime)}</span>
        </div>
      ) : (
        <button
          type="button"
          onClick={startRecording}
          className="text-gray-400 hover:text-white"
        >
          <Mic size={20} />
        </button>
      )}
    </div>
  );
}