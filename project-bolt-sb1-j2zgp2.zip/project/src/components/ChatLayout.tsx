import React from 'react';
import { MessageSquare, Users, Settings, Search, Menu } from 'lucide-react';
import Sidebar from './Sidebar';
import ChatRoom from './ChatRoom';
import UserProfile from './UserProfile';

export default function ChatLayout() {
  const [selectedRoom, setSelectedRoom] = React.useState('anime-general');
  const [sidebarOpen, setSidebarOpen] = React.useState(true);

  return (
    <div className="flex h-screen bg-gray-900 text-white">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-gray-800 transition-all duration-300`}>
        <Sidebar isCollapsed={!sidebarOpen} onToggle={() => setSidebarOpen(!sidebarOpen)} />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        <ChatRoom roomId={selectedRoom} />
      </div>

      {/* User Profile & Online Users */}
      <div className="w-72 bg-gray-800 border-l border-gray-700">
        <UserProfile />
      </div>
    </div>
  );
}