import React from 'react';
import { format } from 'date-fns';
import { MessageSquare } from 'lucide-react';
import type { Message } from '../lib/types';

interface MessageThreadProps {
  message: Message;
  replies: Message[];
  onReply: () => void;
}

export default function MessageThread({ message, replies, onReply }: MessageThreadProps) {
  return (
    <div className="ml-14 mt-2">
      {replies.length > 0 && (
        <div className="space-y-2">
          {replies.map((reply) => (
            <div key={reply.id} className="flex items-start space-x-3 pl-4 border-l-2 border-gray-700">
              <img
                src={`https://api.dicebear.com/7.x/avatars/svg?seed=${reply.userId}`}
                alt="avatar"
                className="w-8 h-8 rounded-full bg-gray-700"
              />
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-sm">{reply.userId}</span>
                  <span className="text-xs text-gray-400">
                    {format(new Date(reply.timestamp), 'p')}
                  </span>
                </div>
                <p className="text-sm text-gray-300">{reply.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}
      
      <button
        onClick={onReply}
        className="mt-2 flex items-center space-x-2 text-sm text-gray-400 hover:text-white"
      >
        <MessageSquare size={16} />
        <span>{replies.length > 0 ? `${replies.length} replies` : 'Reply'}</span>
      </button>
    </div>
  );
}