import React from 'react';
import { useAtomValue } from 'jotai';
import { Toaster } from 'sonner';
import { isAuthenticatedAtom, themeAtom } from './lib/store/atoms';
import ChatLayout from './components/ChatLayout';
import LoginForm from './components/auth/LoginForm';

function App() {
  const isAuthenticated = useAtomValue(isAuthenticatedAtom);
  const theme = useAtomValue(themeAtom);

  return (
    <div className={`h-screen ${theme === 'dark' ? 'bg-gray-900' : 'bg-gray-50'}`}>
      {isAuthenticated ? (
        <ChatLayout />
      ) : (
        <div className="h-full flex items-center justify-center p-4">
          <div className="w-full max-w-md">
            <h1 className="text-3xl font-bold text-center mb-8 text-white">
              Welcome to AnimeChat
            </h1>
            <LoginForm />
          </div>
        </div>
      )}
      <Toaster position="top-right" theme={theme} />
    </div>
  );
}

export default App;