export interface User {
  id: string;
  username: string;
  email: string;
  avatar: string;
  status: 'online' | 'idle' | 'dnd' | 'offline';
  interests: string[];
  level: number;
  createdAt: string;
}

export interface Message {
  id: string;
  content: string;
  userId: string;
  roomId: string;
  timestamp: string;
  attachments?: Attachment[];
  reactions?: Record<string, string[]>;
}

export interface Room {
  id: string;
  name: string;
  category: string;
  description: string;
  memberCount: number;
  lastActivity: string;
}

export interface Attachment {
  id: string;
  type: 'image' | 'video' | 'audio' | 'file';
  url: string;
  name: string;
  size: number;
}

export type Theme = 'light' | 'dark';