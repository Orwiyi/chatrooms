import { useState, useEffect } from 'react';
import type { Message } from '../types';

export function useSearch(roomId: string, query: string) {
  const [results, setResults] = useState<Message[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const search = async () => {
      setIsSearching(true);
      try {
        // Simulated search - replace with actual API call
        await new Promise(resolve => setTimeout(resolve, 500));
        // Mock results
        setResults([
          {
            id: '1',
            content: 'Found message containing ' + query,
            userId: 'user1',
            roomId,
            timestamp: new Date().toISOString(),
          },
        ]);
      } catch (error) {
        console.error('Search failed:', error);
      } finally {
        setIsSearching(false);
      }
    };

    const debounce = setTimeout(search, 300);
    return () => clearTimeout(debounce);
  }, [roomId, query]);

  return { results, isSearching };
}