import { useState, useEffect, useCallback } from 'react';
import { useAtomValue } from 'jotai';
import { socket } from '../socket';
import { userAtom } from '../store/atoms';
import type { Message } from '../types';

export function useChat(roomId: string) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState<string[]>([]);
  const user = useAtomValue(userAtom);

  useEffect(() => {
    if (!user) return;

    socket.emit('join_room', roomId);

    socket.on('message', (message: Message) => {
      setMessages(prev => [...prev, message]);
    });

    socket.on('typing_start', (username: string) => {
      setIsTyping(prev => [...prev, username]);
    });

    socket.on('typing_end', (username: string) => {
      setIsTyping(prev => prev.filter(u => u !== username));
    });

    return () => {
      socket.emit('leave_room', roomId);
      socket.off('message');
      socket.off('typing_start');
      socket.off('typing_end');
    };
  }, [roomId, user]);

  const sendMessage = useCallback((content: string) => {
    if (!user) return;

    const message = {
      id: crypto.randomUUID(),
      content,
      userId: user.id,
      roomId,
      timestamp: new Date().toISOString(),
    };

    socket.emit('message', message);
  }, [roomId, user]);

  const startTyping = useCallback(() => {
    if (!user) return;
    socket.emit('typing_start', roomId, user.username);
  }, [roomId, user]);

  const stopTyping = useCallback(() => {
    if (!user) return;
    socket.emit('typing_end', roomId, user.username);
  }, [roomId, user]);

  return {
    messages,
    isTyping,
    sendMessage,
    startTyping,
    stopTyping,
  };
}