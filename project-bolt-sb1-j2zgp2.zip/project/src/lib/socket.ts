import { io } from 'socket.io-client';

export const socket = io('https://api.improvedconcept.com', {
  autoConnect: false,
});

export const connectSocket = (token: string) => {
  socket.auth = { token };
  socket.connect();
};

export const disconnectSocket = () => {
  socket.disconnect();
};