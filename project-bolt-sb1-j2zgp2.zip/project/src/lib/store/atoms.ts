import { atom } from 'jotai';
import { type User, type Theme } from '../types';

export const userAtom = atom<User | null>(null);
export const themeAtom = atom<Theme>('dark');
export const isAuthenticatedAtom = atom((get) => get(userAtom) !== null);
export const onlineUsersAtom = atom<User[]>([]);